﻿using System;

namespace P310_Console
{
    class Program
    {
        static void Main()
        {
            #region boxing & unboxing
            //int n = 10;
            //object obje = "dfgfd"; //boxing

            //int? m = obje as int?;

            //Console.WriteLine(m);
            #endregion

            Person p = new Person() { Birtdate = new DateTime(1991, 10, 10) };
            Person p2 = new Person() { Birtdate = new DateTime(1991, 10, 10) };

            Console.WriteLine(p.CompareTo(p2));

            SortItems<Person>(new Person[] { p, p2 });
        }

        static void SortItems<T>(T[] items) where T : IComparable  //generic method
        {
            //[10, 15, 5, -2, 45]
        }
    }

    class Person : IComparable
    {
        public string Firstname { get; set; }
        public DateTime Birtdate { get; set; }

        public int CompareTo(object obj)
        {
            Person coldenGelen = (Person)obj;

            if (this.Birtdate.Year > coldenGelen.Birtdate.Year) return -1;
            if (this.Birtdate == coldenGelen.Birtdate) return 0;
            return 1;
        }
    }

    //interface IComparable
    //{
    //    void Compare(int a, int b);
    //}

    //abstract class Comparable
    //{
    //    public abstract void Compare(int a, int b);
    //}

    class Queue<T, J> where J : T            //generic type
    {
        private readonly T[] _queue;
        private int tail = 0;
        private int head = 0;

        public Queue(uint len)
        {
            _queue = new T[len];
        }

        /// <summary>
        /// This method will be used to add element to the end of the queue
        /// </summary>
        /// <param name="item">Element to add to the queue</param>
        public void Enqueue(T item)
        {
            if (tail == _queue.Length)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Queue is full");
                Console.ForegroundColor = ConsoleColor.White;
                return;
            }
            _queue[tail++] = item;
        }

        public T Dequeue()
        {
            if (head == 0 && _queue[head] == null
               ||
               head == _queue.Length)
            {
                throw new IndexOutOfRangeException("There is nobody in the queue");
            }
            else
            {
                return _queue[head++];
            }
        }
    }
}